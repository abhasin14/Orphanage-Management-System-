A Pen created at CodePen.io. You can find this one at https://codepen.io/daviddarnes/pen/VLXxMa.

 Sample buttons from my Sullivan template for BaseKit. Checkout [the dribbble shot](https://dribbble.com/shots/2138517-Sullivan-Buttons).

You'll soon be able to try out this template, along with others, by signing up for free at [developers.basekit.com](http://developers.basekit.com)